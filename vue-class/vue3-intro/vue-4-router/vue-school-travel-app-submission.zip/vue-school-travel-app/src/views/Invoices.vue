<template>
    <div>
      <h1>Invoices</h1>
    </div>
  </template>